from PyQt6.QtWidgets import * 
import sys
import re
from langchain.llms import Ollama
from langchain.callbacks.manager import CallbackManager
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain import PromptTemplate
from langchain.vectorstores import Chroma
from langchain.embeddings import GPT4AllEmbeddings
from langchain.chains import RetrievalQA

def generate_response(input_query):
    llm = Ollama(base_url="http://localhost:11434", model="llama2", verbose=False, callback_manager = CallbackManager([StreamingStdOutCallbackHandler()]))
    vectorstore = Chroma(persist_directory="./chroma_db", embedding_function=GPT4AllEmbeddings())
    question = input_query
    template = """Use the following pieces of context to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer. 
    Use three sentences maximum and keep the answer as concise as possible. 
    {context}
    Question: {question}
    Helpful Answer:"""
    QA_CHAIN_PROMPT = PromptTemplate(
        input_variables=["context", "question"],
        template=template,
    )
    qa_chain = RetrievalQA.from_chain_type(
        llm,
        retriever=vectorstore.as_retriever(),
        chain_type_kwargs={"verbose": False, "prompt": QA_CHAIN_PROMPT}, 
        return_source_documents=True,
        verbose=False
    )
    result = qa_chain({"query": question}, return_only_outputs=True)
    return result

def createhtml(myDict: dict):
    currentResult = myDict["result"]
    sourceDocArray = myDict["source_documents"]
    resultelements = currentResult.split("\n")
    theHTML = "<html>"
    for e in resultelements:
        theHTML += "<p>" + e + "</p>"
    theHTML += "<br><h4>References</h4><ul>"
    for content in sourceDocArray:
        ref = content.page_content
        source = content.metadata["source"]
        source = re.sub(r'^.*?_','', source)
        source = source[:-4]
        theHTML += "<li>" + ref + " (<b>Source:</b> " + source + ")</li>"
    theHTML += "</ul></html>"
    return theHTML


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.n_times_clicked = 0 
        layout = QVBoxLayout()
        self.setWindowTitle("rhea.framework RecommendationAI") 
        self.queryinput = QPlainTextEdit()
        self.queryinput.setMaximumHeight(80)
        self.button = QPushButton("Query")
        self.button.clicked.connect(self.the_button_was_clicked) 
        self.button.setMinimumWidth(350)
        self.resultview = QTextBrowser()
        layout.addWidget(self.queryinput)
        layout.addWidget(self.button)
        layout.addWidget(self.resultview)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def the_button_was_clicked(self):
        q = str(self.queryinput.toPlainText()) 
        if q and not q.isspace():
            currentresult = generate_response(q)
            someHTML = createhtml(currentresult)
            self.resultview.setText(someHTML)
        else:
            self.resultview.setText("rhea.framework RecommendationAI")

if __name__ == '__main__':
    app = QApplication(sys.argv) 
    window = MainWindow() 
    window.show() 
    sys.exit(app.exec())
